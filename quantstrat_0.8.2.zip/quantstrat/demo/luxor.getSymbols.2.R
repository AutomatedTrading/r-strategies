#!/usr/bin/Rscript --vanilla
#
# Jan Humme (@opentrades) - August 2012, revised April 2013
#
# Tested and found to work correctly using blotter r1457
#
# After Jaekle & Tamasini: A new approach to system development and portfolio optimisation (ISBN 978-1-905641-79-6)
#
# loading symbol data

Sys.setenv(TZ="UTC")

### packages
#
# quantstrat package will pull in some other packages:
# FinancialInstrument, quantmod, blotter, xts

require(quantstrat)

### FinancialInstrument

currency(c('GBP', 'USD'))

exchange_rate('GBPUSD', tick_size=0.0001)

path <- "C:/Users/riosp/Google Drive/time_series/simulacion_acciones"
forex.1M<-read.csv(unz(paste(path,"DAT_GBPUSD_M1_2002_2008.zip",sep="/"),"DAT_GBPUSD_M1_2002_2008.csv"), sep=";", header=FALSE)
forex.1M<-as.xts(zoo(forex.1M[,c(2:5)]),as.POSIXct(forex.1M[,c(1)], "%Y%m%d %H%M%S", tz="UTC"))

### xts
GBPUSD = to.minutes30(forex.1M)
GBPUSD = align.time(GBPUSD, 1800)

# .from and .to defined in luxor.include.R
GBPUSD<-GBPUSD[paste0(.from,'::',.to)]

names(GBPUSD)<-c("GBPUSD.Open", "GBPUSD.High", "GBPUSD.Low", "GBPUSD.Close")
